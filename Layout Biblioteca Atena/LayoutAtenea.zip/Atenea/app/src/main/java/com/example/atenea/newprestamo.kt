package com.example.atenea

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class newprestamo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_newprestamo)

        val button14= findViewById<Button>(R.id.btnCerrarPrestamo)

        button14.setOnClickListener{
            val intent= Intent(this, gprestamo::class.java)
            startActivity(intent)
        }

        val button15 = findViewById<Button>(R.id.btn_confirmar_prestamo)

        button15.setOnClickListener{
            val intent= Intent(this, gprestamo::class.java)
            startActivity(intent)
        }
    }
}