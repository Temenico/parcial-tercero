package com.example.atenea

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class gcliente : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gcliente)

        val button4 = findViewById<Button>(R.id.btnRegresarCliente)

        button4.setOnClickListener{
            val intent= Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val button5 = findViewById<Button>(R.id.btnNuevoCliente)

        button5.setOnClickListener{
            val intent=Intent(this, newcliente::class.java)
            startActivity(intent)
        }
    }
}