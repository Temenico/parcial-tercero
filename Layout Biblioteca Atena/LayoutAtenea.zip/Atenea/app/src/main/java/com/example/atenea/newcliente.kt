package com.example.atenea

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class newcliente : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_newcliente)

        val button10= findViewById<Button>(R.id.btnCerrarCliente)

        button10.setOnClickListener{
            val intent= Intent(this, gcliente::class.java)
            startActivity(intent)
        }

        val button11 = findViewById<Button>(R.id.btn_confirmar_cliente)

        button11.setOnClickListener{
            val intent= Intent(this, gcliente::class.java)
            startActivity(intent)
        }
    }
}