package com.example.atenea

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class newlibro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_newlibro)

        val button12= findViewById<Button>(R.id.btnCerrarLibro)

        button12.setOnClickListener{
            val intent= Intent(this, glibro::class.java)
            startActivity(intent)
        }

        val button13 = findViewById<Button>(R.id.btn_confirmar_libro)

        button13.setOnClickListener{
            val intent= Intent(this, glibro::class.java)
            startActivity(intent)
        }
    }
}